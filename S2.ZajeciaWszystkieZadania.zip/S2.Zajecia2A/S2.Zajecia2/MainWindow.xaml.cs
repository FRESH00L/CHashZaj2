﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Printing.IndexedProperties;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace S2.Zajecia2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        //ZADANIE A
        double Iloczyn(double x, double y)
        {
            return x * y;
        }

        double Kwadrat(double x) 
        {
            return Iloczyn(x,x);
        }

        double PoleKola(double r) 
        {
            r = Kwadrat(r);
            return Iloczyn(Math.PI, r);
        }

        double ObjetoscWalca(double h,double r)
        {
            double P = PoleKola(r);
            return Iloczyn(h,P);
        }

        double ObjetoscWalca(double h)
        {
            return ObjetoscWalca(h / 2, h);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            double x = 2;
            double y = 4;
            double r = 5;
            double h = 6;

            lbxLista.Items.Clear();

            lbxLista.Items.Add(Iloczyn(x, y).ToString("F3"));
            lbxLista.Items.Add(Kwadrat(x).ToString("F3"));
            lbxLista.Items.Add(PoleKola(r).ToString("F3"));
            lbxLista.Items.Add(ObjetoscWalca(h,r).ToString("F3"));
            lbxLista.Items.Add(ObjetoscWalca(h).ToString("F3"));
        }

        /////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //ZADANIE B

        double Potega(double podstawa, int wykladnik)
        {
            double wynik;
            if (wykladnik >0)
            {
                --wykladnik;
                wynik = podstawa * Potega(podstawa, wykladnik);
                return wynik;
            }
            else
                return 1;
            
        }
        private void btn_Potega_Click(object sender, RoutedEventArgs e)
        {
            try { 
            double podstawa = Convert.ToDouble(tb_podstawa.Text);
            int wykladnik = Convert.ToInt32(tb_wykladnik.Text);
            if(wykladnik < 0) { throw new ArgumentException(); }
            double wynik = Potega(podstawa, wykladnik);
                MessageBox.Show($"Wynik potęgowania {podstawa} do {wykladnik} potęgi to: {wynik}", "Wynik", MessageBoxButton.OK);
            }
            catch (ArgumentException){
                MessageBox.Show("Niepoprawne dane...", "Błąd", MessageBoxButton.OK);
            }

        }

        /////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //ZADANIE C

        void Prostokat(in double a, in double b, out double P, out double O, out double Prz)
        {
            P = a * b;
            O = 2 * a + 2 * b;
            Prz = Math.Sqrt(a * a + b * b);
        }

        private void btn_Oblicz_Click(object sender, RoutedEventArgs e)
        {
            double a = Convert.ToDouble(tb_a.Text);
            double b = Convert.ToDouble(tb_b.Text);
            double P, O, Prz;
            Prostokat(in a, in b, out P, out O, out Prz);
            MessageBox.Show($"Pole = {P}, Obwód = {O}, Przekątna = {Prz:F3}","Wyniki",MessageBoxButton.OK);
        }

        /////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //ZADANIE D

        void RysujLinie(int x1,int y1, int x2, int y2, Color color)
        {
            SolidColorBrush clr = new SolidColorBrush(color);
            var myLine = new Line();
            myLine.StrokeThickness = 3;
            myLine.Stroke = clr;
            myLine.X1=x1; 
            myLine.Y1=y1;
            myLine.X2=x2;
            myLine.Y2=y2;
            cv_Rysunek.Children.Add(myLine);
        }

        private void btn_Rysuj_Click(object sender, RoutedEventArgs e)
        {
            int[,] wspolrzedne = new int[,] {
                { 100, 50, 100, 250 },
                { 300, 50, 300, 250 },
                { 100, 150, 300, 150 },
                { 100, 50, 300, 50 } };
            Color[] kolory = { Colors.Green, Colors.Green, Colors.Red, Colors.Black };
            for (int i = 0;i<4;i++) 
            {
                RysujLinie(wspolrzedne[i, 0], wspolrzedne[i, 1], wspolrzedne[i, 2], wspolrzedne[i, 3], kolory[i]);
            }
        }

        /////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //ZADANIE E

        enum Rodzaj{Sum,Min,Max};

        Rodzaj CoWybrane()
        {
            if(rd_Max.IsChecked == true)
                return Rodzaj.Max;
            if (rd_Min.IsChecked == true)
                return Rodzaj.Min;
            else return Rodzaj.Sum;
        }

        int Sum(params int[] tab)
        {
            int wynik = 0;
            foreach (int i in tab)
                wynik += i;
            return wynik;
        }

        int Min(params int[] tab)
        {
            int najmniejsza = tab[0];
            foreach (var item in tab)
            {
                if(item < najmniejsza)
                    najmniejsza = item;
            }
            return najmniejsza;
        }

        int Max(params int[] tab)
        {
            int najwieksza = tab[0];
            foreach (var item in tab)
            {
                if (item > najwieksza)
                    najwieksza = item;
            }
            return najwieksza;
        }

        int Metoda(Rodzaj _rodzaj, params int[] tab )
        {
            lbxLista.Items.Clear();
            foreach(int el in tab)
            {
                lbxLista.Items.Add(el);
            }
            switch(_rodzaj)
            {
                case Rodzaj.Sum:
                    return Sum(tab);
                case Rodzaj.Min:
                    return Min(tab);
                case Rodzaj.Max:
                    return Max(tab);
                default:
                    throw new ArgumentException("Nieprawidłowa operacja...");
            }    
            
        }

        private void btn_Wyswietl_Click(object sender, RoutedEventArgs e)
        {
            Rodzaj wybranyRodzaj = CoWybrane();
            int[] listaTestowa = { 10, 20, 30, 40, 50 };
            int wynik = Metoda(wybranyRodzaj, listaTestowa);
            MessageBox.Show($"Wynik to {wynik}", "Wynik", MessageBoxButton.OK);
        }



        ////////////////////////////////////////////////////////////////////
        //ZADANIE DOMOWE 1

        private void RysujLinie(double x1, double y1, double x2, double y2)
        {
            var myLine = new Line();
            myLine.StrokeThickness = 3;
            myLine.Stroke = System.Windows.Media.Brushes.Blue;
            myLine.X1 = x1;
            myLine.Y1 = y1;
            myLine.X2 = x2;
            myLine.Y2 = y2;
            cv_gwiazwa.Children.Add(myLine);
        }

        private void RysujGwiazde(double srodekX, double srodekY, double dlugosc)
        {
            

            RysujLinie(srodekX, srodekY, srodekX + dlugosc, srodekY);
            RysujLinie(srodekX, srodekY, srodekX - dlugosc, srodekY);
            RysujLinie(srodekX, srodekY, srodekX + 0.7*dlugosc, srodekY - 0.7* dlugosc);
            RysujLinie(srodekX, srodekY, srodekX - 0.7*dlugosc, srodekY - 0.7* dlugosc);
            RysujLinie(srodekX, srodekY, srodekX - 0.7*dlugosc, srodekY + 0.7* dlugosc);
            RysujLinie(srodekX, srodekY, srodekX + 0.7*dlugosc, srodekY + 0.7* dlugosc);

            if (dlugosc > 1)
            {

                RysujGwiazde(srodekX + 0.7 * dlugosc, srodekY - 0.7 * dlugosc, 1.0/3.0 * dlugosc);
                RysujGwiazde(srodekX - 0.7 * dlugosc, srodekY - 0.7 * dlugosc, 1.0 / 3.0 * dlugosc);
                RysujGwiazde(srodekX - 0.7 * dlugosc, srodekY + 0.7 * dlugosc, 1.0 / 3.0 * dlugosc);
                RysujGwiazde(srodekX + 0.7 * dlugosc, srodekY + 0.7 * dlugosc, 1.0 / 3.0 * dlugosc);
                RysujGwiazde( srodekX + dlugosc, srodekY, 1.0/3.0 * dlugosc);
                RysujGwiazde( srodekX - dlugosc, srodekY, 1.0/3.0 *dlugosc);

            }


        }

        private void btn_gwiazda_Click(object sender, RoutedEventArgs e)
        {
            RysujGwiazde(100, 100, 70);

        }
        //////////////////////////////////////////////////////////////////////////////////////////////
        //ZADANIE DOMOWE 2
        private void swapPlaces(ref int A, ref int B )
        {
            int temp = A;
            A = B;
            B = temp;
        }

        private void btn_swap_Click(object sender, RoutedEventArgs e)
        {
            int A = Convert.ToInt32(tb_liczbaA.Text);
            int B = Convert.ToInt32(tb_liczbaB.Text);
            swapPlaces(ref A, ref B);
            MessageBox.Show($"Po zamianie miejscami A = {A} oraz B = {B}", "Wynik", MessageBoxButton.OK);
        }


        //////////////////////////////////////////////////////////////////////////////////////////////
        //ZADANIE DOMOWE 3
        private void btn_tab_Click(object sender, RoutedEventArgs e)
        {
            lbxLista.Items.Clear();
            
            double[,] tablica = new double[,] { { 1.1, 2.2, 3.3 }, { 4.4, 5.5, 6.6 }, { 7.7, 8.8, 9.9}, { 10.1, 11.2, 12.3 }, { 13.4, 14.5, 15.6 } };
            for (int i = 0; i <5; i++)
            {
                    int j = 0;
                    double suma = tablica[i,j] + tablica[i,j+1] +tablica[i,j+2];
                    String str = $"{tablica[i,j]:F1}   {tablica[i,j+1]:F1}   {tablica[i,j+2]:F1} [{suma}:F1]";
                    lbxLista.Items.Add(str);
                
            }
        }

        //////////////////////////////////////////////////////////////////////////////////////////////
        //ZADANIE DOMOWE 4
        private void btn_jagged_Click(object sender, RoutedEventArgs e)
        {
            lbxLista.Items.Clear();
            int[][] tab = new int[3][];
            int rowNum = 8;
            
            for(int i =0;i<=tab.Length;i++)
            {
                
                int itemValue = 2;
                int sum = 0;
                if (rowNum > 2)
                {
                    int[] tablica = new int[rowNum];
                    string str = " ";
                    for (int j = 0; j < tablica.Length; j++)
                    {
                        if (j < tablica.Length-1)
                        {
                            tablica[j] = itemValue;
                            itemValue++;
                            sum += tablica[j];
                            string str2 = Convert.ToString(tablica[j]);
                            str = str + "   " + str2;
                        }
                        else
                        {
                            tablica[j] = sum;
                            string str2 = Convert.ToString(tablica[j]);
                            str = str + "   [" + str2 + "]";
                        }
                        
                    }
                    lbxLista.Items.Add(str);
                    rowNum--;
                    rowNum--;
                }
            }
        }




    }
}
