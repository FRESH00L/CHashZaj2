﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace S2.Zajecia2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        double Iloczyn(double x, double y)
        {
            return x * y;
        }

        double Kwadrat(double x) 
        {
            return Iloczyn(x,x);
        }

        double PoleKola(double r) 
        {
            r = Kwadrat(r);
            return Iloczyn(Math.PI, r);
        }

        double ObjetoscWalca(double h,double r)
        {
            double P = PoleKola(r);
            return Iloczyn(h,P);
        }

        double ObjetoscWalca(double h)
        {
            return ObjetoscWalca(h / 2, h);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            double x = 2;
            double y = 4;
            double r = 5;
            double h = 6;

            lbxLista.Items.Clear();

            lbxLista.Items.Add(Iloczyn(x, y));
            lbxLista.Items.Add(Kwadrat(x));
            lbxLista.Items.Add(PoleKola(r));
            lbxLista.Items.Add(ObjetoscWalca(h,r));
            lbxLista.Items.Add(ObjetoscWalca(h));
        }
    }
}
