﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace S2.Zajecia2D
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        void RysujLinie(int x1, int y1, int x2, int y2, Color color)
        {
            SolidColorBrush clr = new SolidColorBrush(color);
            var myLine = new Line();
            myLine.StrokeThickness= 3;
            myLine.Stroke = clr;
            myLine.X1 = x1;
            myLine.Y1 = y1;
            myLine.X2 = x2;
            myLine.Y2 = y2;

            cv.Children.Add(myLine);
        }
        private void btnTest_Click(object sender, RoutedEventArgs e)
        {
            int[,] points = { 
                { 100, 50, 100, 250 },
                { 300, 50, 300, 250 },
                { 100, 150, 300, 150 },
                { 100, 50, 300, 50 } 
            };
            Color[] colors = { Colors.Green, Colors.Green, Colors.Red, Colors.Black };
            
            for(int i = 0; i< 4; i++) 
            {
                RysujLinie(points[i,0], points[i,1], points[i,2], points[i,3], colors[i]);
            }
        }
    }
}
